//
//  Homework01Tests.h
//  Homework01Tests
//
//  Created by Shibani Mookerjee on 6/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface Homework01Tests : SenTestCase {
@private
    
}

@end
