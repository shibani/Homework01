//
//  Homework01Tests.m
//  Homework01Tests
//
//  Created by Shibani Mookerjee on 6/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Homework01Tests.h"


@implementation Homework01Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in Homework01Tests");
}

@end
