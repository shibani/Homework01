//
//  View.m
//  Homework01
//
//  Created by Shibani Mookerjee on 6/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "View.h"

@implementation View

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor colorWithRed: 0.98 green:0.92 blue:0.84 alpha:1.0];
    }
    return self;
}


- (void)drawRect:(CGRect)rect
{

//    NSString *s = @"Modern Art!";
    NSString *s = NSLocalizedString(@"Title", @"displayed with drawAtPoint:");
    UIFont *f = [UIFont boldSystemFontOfSize:14];
        
    CGSize b = self.bounds.size;
    CGFloat max = MAX(b.width, b.height);
    CGFloat height = max * 6/8;
    CGFloat width = max * 4/8;
    
    CGSize size = [s sizeWithFont: f];
    CGPoint t = CGPointMake((b.width - size.width) / 2, (b.height * 0.125 - size.height)/2);    
    [s drawAtPoint:t withFont:f];
    
//    CGPoint t = CGPointMake(b.width / 2 - width / 2, b.height / 2 + height / 2); //check for 0,0
//    [@"O" drawAtPoint:CGPointZero withFont:f]; //check for 0,0
//    [@"O" drawAtPoint:t withFont:f]; //check for 0,0
    
        
    //frame and background
    CGMutablePathRef p = CGPathCreateMutable();   //right triangle
	CGPathMoveToPoint(p, NULL, 0, 0);          //lower right vertex (the right angle)
	CGPathAddLineToPoint(p, NULL, 0, height);  //upper right vertex
	CGPathAddLineToPoint(p, NULL, width, height); //lower left vertex
    CGPathAddLineToPoint(p, NULL, width, 0);
	CGPathCloseSubpath(p);
    
    CGContextRef c = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM(c,  (b.width - width) / 2 , (b.height + height) / 2);
    CGContextScaleCTM(c, 1, -1);
    
	CGContextBeginPath(c); //fill: unnecessary here: the path is already empty.
    CGContextAddPath(c, p);
    CGContextSetRGBFillColor(c, 1.0, 1.0, 1.0, 1.0);
    CGContextFillPath(c);
    
    CGContextBeginPath(c); //stroke: unnecessary here: the path is already empty.
    CGContextAddPath(c, p);
    CGContextSetLineWidth(c, 5.0);
    CGContextSetRGBStrokeColor(c, 0.1, 0.1, 0.1, 1.0);
    CGContextStrokePath(c);    
    
    //blue square at bottom left
    CGMutablePathRef q = CGPathCreateMutable();   
	CGPathMoveToPoint(q, NULL, 0, 0);          
	CGPathAddLineToPoint(q, NULL, 0, height/5);  
	CGPathAddLineToPoint(q, NULL, width/5, height/5); 
    CGPathAddLineToPoint(q, NULL, width/5, 0);
	CGPathCloseSubpath(q);

    CGContextRef d = UIGraphicsGetCurrentContext();
    CGContextBeginPath(d); //unnecessary here: the path is already empty.
    CGContextAddPath(d, q);
    CGContextSetRGBFillColor(d, 0, 0, 1.0, 1.0);
    CGContextFillPath(d);
    
    CGContextBeginPath(d); //stroke: unnecessary here: the path is already empty.
    CGContextAddPath(d, q);
    CGContextSetLineWidth(d, 5.0);
    CGContextSetRGBStrokeColor(d, 0.1, 0.1, 0.1, 1.0);
    CGContextStrokePath(d);
    
    //red square at top right
    CGMutablePathRef u = CGPathCreateMutable();   //right triangle
	CGPathMoveToPoint(u, NULL, 0, 0);          //lower right vertex (the right angle)
	CGPathAddLineToPoint(u, NULL, 0, height * 0.8);  //upper right vertex
	CGPathAddLineToPoint(u, NULL, width * 0.8, height * 0.8); //lower left vertex
    CGPathAddLineToPoint(u, NULL, width * 0.8, 0);
	CGPathCloseSubpath(u);
    
    CGContextRef e = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM (e, width , height) ;
    CGContextRotateCTM(e, M_PI );
    CGContextBeginPath(e); //fill: unnecessary here: the path is already empty.
    CGContextAddPath(e, u);
    CGContextSetRGBFillColor(e, 1.0, 0, 0, 1.0);
    CGContextFillPath(e);

    CGContextBeginPath(e); //stroke: unnecessary here: the path is already empty.
    CGContextAddPath(e, u);
    CGContextSetLineWidth(e, 5.0);
    CGContextSetRGBStrokeColor(e, 0.1, 0.1, 0.1, 1.0);
    CGContextStrokePath(e);
    
    //container for yellow square at bottom right
    CGMutablePathRef v = CGPathCreateMutable();   
	CGPathMoveToPoint(v, NULL, 0, 0);          
	CGPathAddLineToPoint(v, NULL, 0, height * 0.2);  
	CGPathAddLineToPoint(v, NULL, width * 0.2, height * 0.2); 
    CGPathAddLineToPoint(v, NULL, width * 0.2, 0);
	CGPathCloseSubpath(v);
    
    CGContextRef g = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM (g, width * 0.2, height);
    CGContextRotateCTM(g, M_PI);    
    CGContextBeginPath(g); //stroke: unnecessary here: the path is already empty.
    CGContextAddPath(g, v);
    CGContextSetLineWidth(g, 5.0);
    CGContextSetRGBStrokeColor(g, 0.1, 0.1, 0.1, 1.0);
    CGContextStrokePath(g);

    //yellow square at bottom right
    CGMutablePathRef w = CGPathCreateMutable();   
	CGPathMoveToPoint(w, NULL, 0, 0);          
	CGPathAddLineToPoint(w, NULL, 0, height * 0.1);  
	CGPathAddLineToPoint(w, NULL, width * 0.2, height * 0.1); 
    CGPathAddLineToPoint(w, NULL, width * 0.2, 0);
	CGPathCloseSubpath(w);
    
    CGContextRef j = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM (j, width * 0.2, height * 0.1);
    CGContextRotateCTM(j, M_PI);  
    
    CGContextBeginPath(j); //fill: unnecessary here: the path is already empty.
    CGContextAddPath(j, w);
    CGContextSetRGBFillColor(j, 1.0, 1.0, 0, 1.0);
    CGContextFillPath(j);
    
    CGContextBeginPath(j); //stroke: unnecessary here: the path is already empty.
    CGContextAddPath(j, w);
    CGContextSetLineWidth(j, 5.0);
    CGContextSetRGBStrokeColor(j, 0.1, 0.1, 0.1, 1.0);
    CGContextStrokePath(j);

    //clear rect at top left, path not needed, rect ok as we are using only stroke not fill also
    CGRect last = CGRectMake(width * 0.8, -height * 0.9, width * 0.2, height * 0.1);
    CGContextRef k = UIGraphicsGetCurrentContext();
    CGContextBeginPath(k);
    CGContextAddRect(k, last);
    CGContextSetRGBStrokeColor(k, 0.1, 0.1, 0.1, 1.0); //only stroke here, no fill
	CGContextStrokePath(k);
    
    //clear rect overlapping, path not needed, rect ok as we are using only stroke not fill also
    CGContextRef l = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM (l, (-width * 0.25), (-height * 0.25));
    CGRect tall = CGRectMake(width * 0.6, -height * 0.6, width * 0.5, height * 0.5);
  
    CGContextBeginPath(l);
    CGContextAddRect(l, tall);
    CGContextSetRGBStrokeColor(l, 0.1, 0.1, 0.1, 1.0);	//also only stroke here, no fill
	CGContextStrokePath(l);
    
    //rect forcircle
    CGContextRef m = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM (m, (width * 0.4), (-height * 0.4));
    CGRect forcirc = CGRectMake(0, 0, width * 0.5, width * 0.5);
    
    CGContextBeginPath(m);
    CGContextAddEllipseInRect(m, forcirc);//add circle
    CGContextSetRGBStrokeColor(m, 1, 1, 1, 1.0);	
	CGContextStrokePath(m);
   }


- (void)dealloc
{
    [super dealloc];
}

@end
