//
//  View.h
//  Homework01
//
//  Created by Shibani Mookerjee on 6/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface View : UIView {
    
}

@end
