//
//  main.m
//  Homework01
//
//  Created by Shibani Mookerjee on 6/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"Homework01AppDelegate");
    [pool release];
    return retVal;
}
