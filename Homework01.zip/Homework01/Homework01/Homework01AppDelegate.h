//
//  Homework01AppDelegate.h
//  Homework01
//
//  Created by Shibani Mookerjee on 6/28/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class View;

@interface Homework01AppDelegate : NSObject <UIApplicationDelegate> {
    
    View *view;
    UIWindow *_window;

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
